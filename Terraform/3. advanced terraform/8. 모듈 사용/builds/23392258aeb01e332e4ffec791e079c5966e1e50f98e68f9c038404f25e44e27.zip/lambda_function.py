def lambda_handler(event, cotntext):
    print(event)